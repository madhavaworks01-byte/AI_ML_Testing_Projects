import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score

print("Sample Customer Churn Model")
# Dummy sample
data = pd.DataFrame({
    'usage':[10,20,30,40],
    'complaints':[0,1,0,1],
    'churn':[0,1,0,1]
})

X=data[['usage','complaints']]
y=data['churn']
X_train,X_test,y_train,y_test=train_test_split(X,y,test_size=0.5,random_state=42)
model=LogisticRegression()
model.fit(X_train,y_train)
pred=model.predict(X_test)
print("Accuracy:", accuracy_score(y_test,pred))
