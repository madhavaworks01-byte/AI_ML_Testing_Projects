describe('Sample E-commerce Test', () => {
    it('should open website and check title', async () => {
        await browser.url('https://example.com');
        const title = await browser.getTitle();
        console.log("Title:", title);
    });
});
